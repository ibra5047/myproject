Files for the article "How to Make a Perfect Site Maintenance Page (Free Templates Included)"
https://www.wmtips.com/html/howto-make-a-perfect-site-maintenance-page.htm